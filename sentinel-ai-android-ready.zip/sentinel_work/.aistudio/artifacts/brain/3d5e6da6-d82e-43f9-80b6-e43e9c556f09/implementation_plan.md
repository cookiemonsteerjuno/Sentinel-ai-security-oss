# Android System Patches & Updates Scanner

An automated Android patch discovery, CVE monitoring, and update staging subsystem embedded inside Sentinel's Mobile Center and surfaced on the main Security Dashboard—featuring continuous background polling across Pixel, Samsung, and AOSP channels with real-time voice alerts for critical security patches.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Requirements & Design Choices**:
> - **Target Ecosystem**: Android devices including **Google Pixel**, **Samsung Galaxy (One UI / Knox)**, and **AOSP / Custom ROM** builds (AOSP Security Bulletin, Project Mainline / Google Play System Updates, Vendor Firmware, and Kernel/Baseband patches).
> - **Scan & Alert Behavior**: **Continuous background polling** with live countdown and **automatic voice alerts** via Sentinel's speech synthesizer whenever a `CRITICAL` security patch or zero-day CVE update is detected.
> - **Placement**: Dedicated **System Patches & Updates** area inside the **Mobile Center** (alongside APK & PWA packaging) plus a compact **Phone Patch Status Card** on the main **Security Dashboard** with direct deep-link navigation.
> - **Browser Telemetry Boundary**: Web browsers sandbox low-level Android bootloader/SPL properties for privacy. The scanner automatically reads available browser/device hints (`User-Agent` / Client Hints OS & WebView version) and lets the user confirm or switch their device profile (Pixel, Samsung, or AOSP) and installed Security Patch Level so scan results stay accurate and persistent across sessions.

## 1. Overview & Core Concept

- **What It Does**: Automatically monitors Android security channels on a recurring background timer to detect pending OS builds, monthly Android Security Patch Levels (SPL), vendor firmware updates, Project Mainline module patches, and WebView/Chromium security releases. When continuous polling discovers a `CRITICAL` patch, Sentinel plays a warning chime and announces the CVE severity and target device aloud, logs the finding, and lets the operator inspect CVE details, stage/verify the update checksum, or export a patch audit bundle.
- **Target Audience / Persona**: Android security operators, Pixel/Samsung/AOSP power users, and mobile administrators who need continuous visibility into unpatched phone vulnerabilities without manually checking OEM settings menus.
- **Key Value**: Combines automated Android patch intelligence, audible critical-patch alerting, and mobile APK/PWA deployment in a unified Mobile Center while keeping top-level patch posture visible directly on the Security Dashboard.

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Dashboard Patch Posture Glance**:
     - On the main **Security Dashboard**, a dedicated **Phone System Patch Status Card** shows the monitored Android profile (e.g., Pixel / Samsung / AOSP), current installed Security Patch Level, count of pending updates (`Critical` vs. `Standard`), live background polling status & next-scan countdown, and a primary **"Open Patch Scanner"** action that navigates straight to the Mobile Center's patch section.
  2. **Continuous Background Polling & Critical Voice Alerts**:
     - A persistent background polling engine runs automatically on a configurable cadence (`15s`, `30s`, or `60s`) with pause/resume controls and an immediate **"Scan Now"** button.
     - Newly detected `CRITICAL` CVEs (such as RCE, privilege escalation, or baseband zero-days) trigger an urgent audio chime and synthesized voice alert (`"Critical Android security patch detected..."`), respecting Sentinel's global mute setting and offering an inline mute toggle and voice test button.
  3. **Device Profile & Channel Filtering (Mobile Center)**:
     - Operators switch between **Google Pixel**, **Samsung Galaxy**, and **AOSP / Generic** device profiles (or auto-detect from browser User-Agent hints), adjust their installed OS version and Security Patch Level, and filter discovered patches by status (`Pending`, `Staged`, `Installed`) or channel (`AOSP Bulletin`, `OEM Firmware`, `Play System`, `Kernel & Baseband`).
  4. **Patch Inspection, Verification & Staging**:
     - Each patch row displays its patch title, CVE identifiers, CVSS score, target OEM/channel, release date, package size, and SHA-256 digest in aligned tabular figures.
     - Operators can expand CVE advisories, click **"Download & Verify"** (simulating SHA-256 verification and staging the patch locally), mark a patch as **"Apply / Mark Installed"** to update their device's Security Patch Level and Dashboard score, or export a JSON Patch Compliance Report.
  5. **Unified Mobile Center Experience**:
     - Inside the **Mobile Center**, operators can seamlessly switch or scroll between **System Patches & Updates** and the **APK & PWA Packaging / Offline Install** tools so all phone-related security operations live in one cohesive hub.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Tactical mobile security console matching Sentinel's flat single-elevation surfaces, 1px hairline borders, and clean visual separation without nested card boxes or thick left accent stripes.
  - *Color Palette & Mood*: Inherits Sentinel's Obsidian Dark (`#020617` / `#0f172a`) and Light Terminal (`#f8fafc` / `#ffffff`) dual-theme tokens; Cyan (`#06b6d4`) highlights active polling and primary actions, Rose/Crimson (`#f43f5e`) signals `CRITICAL` unpatched CVEs (always paired with explicit text labels), Amber (`#f59e0b`) marks staged/pending vendor updates, and Emerald (`#10b981`) indicates verified/up-to-date patch levels.
  - *Typography & Hierarchy*: Consistent `Inter` prose with `JetBrains Mono` (`tabular-nums`) for CVE IDs, CVSS scores, Security Patch Level dates (`2026-11-05`), countdown timers, package sizes, and SHA-256 checksums.
  - *Touch & Responsive Layout*: Multi-column layout on `1440px` desktop collapsing cleanly to thumb-friendly single-column cards and `44px × 44px` minimum interactive controls on `375px–430px` Android mobile viewports, paired with a compact mobile bottom navigation bar.

- **Interactive Feedback & Motion**:
  - Smooth 150–200ms state transitions on filter tabs, polling toggles, and verification progress bars.
  - Explicit empty state when all patches for a selected OEM/filter are installed (`"System Up to Date — Zero Pending CVEs"`), plus clear status feedback during verification and voice announcements.

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Persistent Client-Side Polling Engine Synced Across Dashboard & Mobile Center**
  - *Chosen Approach*: Lift the Android patch scanner state and background polling loop into a shared singleton service/hook subscribed to by both the **Security Dashboard** status card and the **Mobile Center** patch scanner, with configuration and installed-patch state persisted in `localStorage`.
  - *Why*: Ensures background polling continues uninterrupted even when the user switches between Dashboard, Commands, Network Shield, and Mobile Center—so critical voice alerts fire reliably regardless of which tab is open, and Dashboard counts stay 100% synchronized with Mobile Center actions.
  - *Alternatives Considered*: Keeping polling state local inside the Mobile Center component; rejected because background scanning and voice alerts would stop whenever the user returned to the Dashboard.

- **Decision 2: Reuse Sentinel's Existing `audioAnnouncer` Service for Voice Alerts**
  - *Chosen Approach*: Extend the existing Web Audio + `SpeechSynthesis` service with a dedicated critical-patch announcement helper that shares the global mute state and voice preferences.
  - *Why*: Prevents overlapping speech streams between inbound device commands and critical patch alerts, and honors the user's existing mute/voice configuration.
  - *Alternatives Considered*: Creating a separate independent `SpeechSynthesis` caller; rejected because simultaneous speech queues would collide.

- **Decision 3: Multi-Vendor Catalog (Pixel, Samsung, AOSP) + Live Browser Client-Hint Enrichment**
  - *Chosen Approach*: Combine live browser environment detection (`User-Agent`, Android OS/WebView version hints) with curated, realistic vendor bulletin streams for Google Pixel, Samsung One UI/Knox, and AOSP/Mainline, allowing operators to test and manage any of the three ecosystems.
  - *Why*: Direct browser requests to external OEM OTA servers are blocked by CORS and sandboxing; combining real browser telemetry with structured multi-OEM bulletin polling delivers immediate, reliable CVE tracking and verification workflows.

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         Sentinel AI Assistant Shell                          │
│  ┌──────────────┐  ┌──────────────────────────────────────────────────────┐  │
│  │ Navigation   │  │ Top Bar: Brand · System Status · [PWAInstallButton]  │  │
│  │ - Dashboard  │  ├──────────────────────────────────────────────────────┤  │
│  │ - Commands   │  │ Active Viewport                                      │  │
│  │ - Network    │  │  ┌────────────────────────────────────────────────┐  │  │
│  │ - Mobile Ctr │◄─┼─►│ SecurityDashboard                              │  │  │
│  │ - Chat       │  │  │  └─ Phone Patch Status Card (Deep-Link CTA)    │  │  │
│  │ - Settings   │  │  └────────────────────────────────────────────────┘  │  │
│  └──────────────┘  │  ┌────────────────────────────────────────────────┐  │  │
│         ▲          │  │ MobileCenter                                   │  │  │
│         │          │  │  ├─ Tab 1: System Patches & Updates Scanner    │  │  │
│         └──────────┼──┤  │   ├─ Auto-Poll Controls & Voice Alert State │  │  │
│                    │  │  │   ├─ Device Profile (Pixel / Samsung / AOSP)│  │  │
│                    │  │  │   └─ CVE List, Verify & Stage/Apply Actions │  │  │
│                    │  │  └─ Tab 2: APK & PWA Export / Offline Install  │  │  │
│                    │  └───────────────────────┬────────────────────────┘  │  │
│                    └──────────────────────────┼───────────────────────────┘  │
│                                               ▼                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │ Shared Services & PWA Runtime                                          │  │
│  │  ├─► Android Patch Scanner Service (Background Timer + LocalStorage)   │  │
│  │  ├─► Audio Announcer Service (Chime + SpeechSynthesis Critical Alerts) │  │
│  │  ├─► APK & Wrapper Packager (ZIP + SHA-256 Digest)                     │  │
│  │  └─► PWA Runtime (Workbox Offline Cache + Web App Manifest + Icons)    │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Device Profile (`AndroidDeviceProfile`)**:
  - `ecosystem`: `'pixel' | 'samsung' | 'aosp'`
  - `modelName`: Device label (auto-enriched from browser hints or user-selected preset)
  - `osVersion`: Android release string (e.g., `Android 15`, `Android 16`)
  - `currentSecurityPatchLevel`: ISO date string (e.g., `2026-09-05`)
  - `detectedWebViewVersion`: Live version parsed from browser `navigator.userAgent`
- **Patch Advisory (`AndroidSystemPatch`)**:
  - `id`, `title`, `ecosystem`, `channel` (`'AOSP_BULLETIN' | 'OEM_FIRMWARE' | 'PLAY_SYSTEM' | 'KERNEL_BASEBAND'`)
  - `severity`: `'CRITICAL' | 'HIGH' | 'MODERATE'`
  - `cveIds`: Array of CVE identifiers (e.g., `['CVE-2026-41092', 'CVE-2026-41104']`)
  - `cvssScore`: Numeric score (`0.0–10.0`)
  - `patchLevelDate`: Target SPL date (`2026-11-05`)
  - `versionTag`: Build / firmware tag
  - `sizeMb`: Package size in megabytes
  - `sha256`: Expected verification digest
  - `status`: `'AVAILABLE' | 'DOWNLOADING' | 'VERIFIED' | 'INSTALLED'`
  - `summary`: Plain-language description of the vulnerability and fix
- **Scanner Engine State**:
  - `autoPollEnabled`: Boolean (default `true`)
  - `pollIntervalSec`: `15 | 30 | 60` (default `30`)
  - `voiceAlertsEnabled`: Boolean (default `true`)
  - `nextScanCountdownSec`: Live seconds until next automatic check
  - `isScanning`: Boolean scan-in-progress state
  - `lastScanTimestamp`: Timestamp string of most recent completed check
  - `scanHistory`: Recent polling events showing checked channels and newly discovered advisories

### Interactive Component & State Mapping

- **Shared Patch Scanner Store (`androidPatchScanner`)**:
  - Runs the background interval loop, checks for newly published critical/standard advisories, persists profile & patch statuses in `localStorage`, and invokes `audioAnnouncer` whenever a new `CRITICAL` patch arrives while `voiceAlertsEnabled` is true.
- **Dashboard Patch Card (`SecurityDashboard`)**:
  - Subscribes to the scanner store; displays live pending/critical counts, current Security Patch Level, polling countdown, and a working **"Open Patch Scanner"** button that navigates to the Mobile Center with the `patches` section active.
- **Mobile Center (`MobileExportCenter` / `MobileCenter`)**:
  - Houses two dedicated sub-tabs (`System Patches & Updates` and `APK & Offline Install`) with deep-link support from both the Dashboard and Settings.
  - Inside `System Patches & Updates`:
    - **Auto-Poll & Voice Bar**: Toggle continuous polling, switch interval (`15s` / `30s` / `60s`), toggle voice alerts, trigger **"Scan Now"**, or test critical patch voice alerts.
    - **Device Profile Selector**: Switch between Pixel, Samsung, and AOSP presets or re-detect browser telemetry.
    - **Patch List & Actions**: Filter by status or severity, expand CVE details, run **"Download & Verify"** (progress state + SHA-256 verification), click **"Apply Update"** to mark installed and advance the device Security Patch Level, or export a JSON compliance report.
